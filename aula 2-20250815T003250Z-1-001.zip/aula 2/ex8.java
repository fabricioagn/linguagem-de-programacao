class ex8 {

	public static void main(String args[]){

		float n1 = 7.5f;
		float n2 = 9.0f;
		float n3 = 4.5f;
		System.out.print("m�dia das notas do LPG =");
		System.out.print((n1+n2+n3)/3);

	}
	
}