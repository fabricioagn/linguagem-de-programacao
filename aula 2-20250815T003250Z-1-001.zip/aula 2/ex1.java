class ex1 {

	public static void main(String args[]){

		byte x = 128;
		System.out.println(x);

	}
	
}