class ex3_2 {

	public static void main(String args[]){

		int i = 10;
		int n = ++i;
		System.out.println(n);

	}
	
}