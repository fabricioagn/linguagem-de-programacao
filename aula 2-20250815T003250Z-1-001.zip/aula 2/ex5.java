class ex5 {

	public static void main(String args[]){

		int nasci = 2005;
		int ano = 2024;
		System.out.println(ano-nasci);

	}
	
}