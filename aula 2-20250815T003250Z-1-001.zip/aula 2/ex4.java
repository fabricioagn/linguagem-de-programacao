class ex4 {

	public static void main(String args[]){

		float a = 1.65f;
		int p = 38;
		char artigo = 'a';
		String nome = " raquel";
		double imc = p/(a*a);
		System.out.println("o imc d" + artig + nome + " � iqual a " + imc);

	}
	
}