class ex6 {

	public static void main(String args[]){

		int largura = 25;
		int altura = 90;
		int profundidade = 40;
		System.out.print(largura*altura*profundidade);
		System.out.print("cm de volume");

	}
	
}