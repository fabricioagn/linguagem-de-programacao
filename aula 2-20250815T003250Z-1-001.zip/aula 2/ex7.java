class ex7 {

	public static void main(String args[]){

		int ano_atual = 2024;
		
		if (ano_atual%4 == 0){
		
			System.out.print("� bisesto");

		} else {

			System.out.print("n�o � bisesto");

		}

	}
	
}